ACM Press
---------

The following files are available in the acm-tog.zip archive:

guide.pdf            - This is the PDF file of Author Guide for Template
acmtog.cls           - This is the LaTeX2e class file of TOG
acmtog.bst           - This is the bibliography style file of TOG

TOG-Sample.tex       - LaTeX document of sample
TOG-Sample.pdf       - This is the PDF file of sample LaTeX document of Template
TOG-Sample.bib       - Bibliography file for sample
TOG-Sample-mouse.eps - Graphics file used for latex sample
TOG-Sample-mouse.pdf - Graphics file used for pdflatex sample


Happy TeXing!!!

Aptara