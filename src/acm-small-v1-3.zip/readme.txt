ACM Transactions and Journals (Small Size)
------------------------------------------

The following files are available in acmsmall.zip archive:

acmsmall.cls	     - This is the LaTeX2e class file for acmsmall template
acmsmall.bst	     - This is the bibliography style file for acmsmall template
acmsmall-sam.bib     - This is the bibliography database file
acmsmall-guide.pdf   - This is PDF of Author Guide for acmsmall template
acmsmall-sample.pdf  - This is PDF file of sample LaTeX document for acmsmall template

acmsmall-sample.tex  - LaTeX document of sample
acmsmall-sample.bbl  - LaTeX document of bibliography list
acmsmall-mouse.eps   - Graphics file used in sample
acmsmall-mouse.pdf   - PDF format of graphics file, compatible with pdflatex
algorithm2e.sty	     - Algorithm package used in sample

Happy TeXing!!!
Aptara