// 2009-01-27-22:19
import xtpipes.*;
public class xtpipes {
  public static void main(String [] args) throws Exception {
    Xtpipes.main(args);
} }

